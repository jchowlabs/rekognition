# Deployment Images

This folder contains [Docker](https://docker.com) definitions for deployment artifacts.  Customers can locally install the CDK and related tools on their workstation or utilize these resources for a more consistent experience.
